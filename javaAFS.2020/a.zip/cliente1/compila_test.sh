#!/bin/sh

set -x
javac -cp .:afs_cliente.jar  Test.java
